# 🛡️ ChurnGuard AI: E-Commerce Customer Churn Early Warning System

An intelligent, end-to-end Machine Learning Early Warning System designed to predict at-risk e-commerce customers, explain underlying churn drivers, and trigger automated retention campaigns.

---

## 🚀 Quick Start (How to Run)

### Method 1: 1-Click Launch (Windows)
Double-click `start_project.bat` in the project folder. It will automatically launch the server and open your web browser at `http://127.0.0.1:5000`.

### Method 2: Via Terminal / Command Line
1. Open PowerShell or Command Prompt in the project folder:
   ```bash
   cd "c:\Users\varsh\OneDrive\Desktop\project ibm"
   ```
2. Install dependencies (if not already installed):
   ```bash
   python -m pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python app.py
   ```
4. Open your browser and go to:
   ```text
   http://127.0.0.1:5000
   ```

---

## 📂 Project Architecture & File Directory

```
📁 project ibm/
│
├── 📄 app.py                      # Flask REST API server & routing
├── 📄 generate_dataset.py         # 3,000-record realistic churn dataset generator
├── 📄 train_models.py             # ML pipeline training & multi-model evaluator
├── 📄 ecommerce_customer_churn.csv # Raw & preprocessed dataset
├── 📄 requirements.txt            # Python dependencies
├── 📄 start_project.bat           # 1-Click Windows launch script
│
├── 📁 models/                     # Saved Machine Learning Artifacts
│   ├── 📦 best_model.pkl          # Top-performing serialized pipeline
│   ├── 📦 logistic_regression_pipeline.pkl
│   ├── 📦 random_forest_pipeline.pkl
│   ├── 📦 gradient_boosting_pipeline.pkl
│   ├── 📦 extra_trees_pipeline.pkl
│   └── 📊 model_metrics.json      # Benchmark statistics & feature importances
│
├── 📁 templates/
│   └── 🌐 index.html              # Modern dark-mode glassmorphism dashboard
│
├── 📁 static/
│   ├── 🎨 style.css               # Luxury animations, SVG gauges, card layouts
│   └── ⚡ app.js                  # Client controller, Chart.js & simulation logic
│
└── 📁 documentation/ (Academic & Viva Deliverables)
    ├── 📑 Case_Study_Report.md    # Complete academic & industrial case study
    ├── 📊 PPT_Presentation_Outline.md # 12-slide presentation structure & speaker notes
    ├── 🎓 Reviewer_Viva_Guide.md  # 2-min pitch, demo script, top 15 viva Q&As
    └── 🤖 AI_Prompt_Pack.md       # AI prompts to reproduce or create new models
```

---

## 🌟 Key Application Features

1. **🎯 Real-Time Early Warning Churn Predictor:** Input customer attributes or select 1-click personas (*High-Risk VIP*, *At-Risk User*, *Loyal Advocate*) to get instant risk probability, risk category, and annual revenue at risk.
2. **💡 Automated Retention Strategy Engine:** Prescribes targeted retention actions (e.g. 24h VIP escalation, 20% discount coupon, cart recovery alert).
3. **📊 Multi-Model Machine Learning Arena:** Compare **Logistic Regression (93.17% Acc, 91.98% F1)**, **Gradient Boosting (90.50% Acc)**, and **Random Forest (88.67% Acc)** side-by-side with Chart.js visual charts.
4. **🔮 Interactive What-If Simulator:** Real-time simulation showing how improving customer support tickets reduces churn risk from 78% to 14%.
5. **📂 Batch CSV Customer Scanner:** Drag & drop CSV databases to scan thousands of records in bulk.
6. **💰 Customer Retention ROI Calculator:** Live financial estimation of revenue saved per year.

---

## 🏆 Model Benchmark Summary

| Model Architecture | Accuracy | Precision | Recall (Sensitivity) | F1-Score | ROC-AUC | Status |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression** | **93.17%** | **91.80%** | **92.16%** | **91.98%** | **0.9836** | **★ Top Performer** |
| **Gradient Boosting** | 90.50% | 90.91% | 86.27% | 88.53% | 0.9702 | Benchmark |
| **Random Forest** | 88.67% | 91.19% | 81.18% | 85.89% | 0.9666 | Benchmark |
| **Extra Trees** | 87.67% | 90.22% | 79.61% | 84.58% | 0.9604 | Benchmark |

---

## 🎓 Viva & Presentation Resources
- **Case Study Report:** See [`Case_Study_Report.md`](file:///c:/Users/varsh/OneDrive/Desktop/project%20ibm/Case_Study_Report.md)
- **12-Slide PPT Structure:** See [`PPT_Presentation_Outline.md`](file:///c:/Users/varsh/OneDrive/Desktop/project%20ibm/PPT_Presentation_Outline.md)
- **Viva Questions & Answers:** See [`Reviewer_Viva_Guide.md`](file:///c:/Users/varsh/OneDrive/Desktop/project%20ibm/Reviewer_Viva_Guide.md)
