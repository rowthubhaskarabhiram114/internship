@echo off
title ChurnGuard AI - Customer Retention System
cd /d "%~dp0"
echo ========================================================
echo   Starting ChurnGuard AI Web Dashboard...
echo ========================================================
echo.
echo [*] Opening Web Browser at http://127.0.0.1:5000 ...
timeout /t 1 /nobreak >nul
start http://127.0.0.1:5000
echo [*] Starting Python Flask Server...
python app.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [!] Standard 'python' command failed, trying 'py'...
    py app.py
)
pause
