# AI Prompt Pack (Copy-Paste Prompts for AI Tools)

Use these structured prompts in ChatGPT, Claude, Gemini, or GitHub Copilot to reproduce, customize, or generate new features for this Machine Learning project or any future model project.

---

##  Prompt 1: Generating Custom Synthetic E-Commerce Churn Dataset
```text
Act as a Senior Data Scientist. Write a Python script using pandas and numpy to generate a realistic synthetic E-Commerce Customer Churn dataset with 3,000 samples. 
Include the following features:
- CustomerID (Unique string ID)
- Account_Age_Months (Tenure, 1 to 60)
- Monthly_Spend (Gamma distribution, $15 to $500)
- Purchase_Frequency (Poisson distribution, 0 to 15 orders/month)
- Days_Since_Last_Purchase (1 to 120 days)
- Customer_Support_Calls (0 to 10 complaints)
- Satisfaction_Score (1 to 5 scale)
- Cart_Abandonment_Rate (0.0 to 1.0)
- Discount_Usage_Ratio (0.0 to 1.0)
- Subscription_Tier (Basic, Premium, VIP)
- Device_Type (Mobile App, Desktop, Tablet)
- Payment_Method (Credit Card, UPI/Debit, Digital Wallet, COD)
- Churn (Binary 0 or 1, calculated using a realistic log-odds logistic formula with noise).

Save the output to 'ecommerce_customer_churn.csv' and print class balance statistics.
```

---

##  Prompt 2: Training & Benchmarking Multiple ML Models
```text
Act as a Senior Machine Learning Engineer. Write a complete Python training pipeline script 'train_models.py' using scikit-learn.
Requirements:
1. Load 'ecommerce_customer_churn.csv'.
2. Use ColumnTransformer with StandardScaler for numerical features and OneHotEncoder(handle_unknown='ignore') for categorical features.
3. Split data into 80% train and 20% test with stratified sampling.
4. Train and benchmark 4 models: Logistic Regression, Random Forest, Gradient Boosting, and Extra Trees.
5. Compute Accuracy, Precision, Recall, F1-Score, ROC-AUC, and Confusion Matrix for each.
6. Extract and rank global feature importances.
7. Save the best pipeline and all evaluation metrics to a 'models/' folder using joblib and json.
```

---

##  Prompt 3: Building a Flask REST API & Web Server
```text
Act as a Full-Stack Python Developer. Create a Flask web backend 'app.py' that loads the serialized model pipelines and metrics from the 'models/' directory.
Provide the following REST endpoints:
1. GET / - Renders the dashboard template.
2. GET /api/metrics - Returns model benchmark scores, confusion matrices, and feature importances.
3. GET /api/sample-customer - Returns pre-configured sample customer personas (High Risk, Moderate Risk, Low Risk).
4. POST /api/predict - Accepts customer attributes, runs inference using selected model, returns churn probability (%), risk tier (Low, Moderate, Critical), annual revenue at risk, and rule-based AI retention recommendations.
5. POST /api/what-if - Simulates counterfactual improvements (e.g. resolving support calls) and computes the churn probability reduction delta.
6. POST /api/batch-predict - Accepts an uploaded customer CSV, predicts churn for all records, returns overall statistics and the top 15 highest-risk customer records.
```

---

## Prompt 4: Building a Modern Dashboard UI
```text
Act as a Lead UI/UX Frontend Engineer. Create a modern, luxury dark-mode web dashboard ('templates/index.html' and 'static/style.css' + 'static/app.js') with glassmorphism design, vibrant glowing accents, and Chart.js integration.
The UI must include 5 tabs:
1. Live Predictor: Interactive sliders, dropdowns, 1-click persona buttons, animated circular SVG risk score gauge, and AI retention recommendation cards.
2. Model Comparison: Benchmark table comparing Logistic Regression, Random Forest, and Gradient Boosting, with radar/bar charts and feature importance breakdown.
3. What-If Simulator: Counterfactual comparison tool showing baseline vs simulated customer experience intervention.
4. Batch CSV Scanner: Drag-and-drop file upload with summary metric cards and at-risk customer table.
5. ROI Calculator: Interactive financial return simulator calculating annual revenue saved by retaining customers.
```

---

## Prompt 5: Alternative Model Project (e.g., Credit Risk / Loan Default Prediction)
```text
I want to adapt this early warning framework to another business domain: "Banking Credit Risk & Loan Default Early Warning System".
Please provide:
1. Complete list of relevant financial and behavioral features (Credit Score, Debt-to-Income Ratio, Annual Income, Missed Payments, Loan Amount, Employment Length, Home Ownership).
2. Data generation script with realistic default risk formulas.
3. Multi-model pipeline script comparing XGBoost, Random Forest, and Logistic Regression.
4. Prescriptive risk mitigation recommendations (e.g., Loan restructuring, collateral requirement, credit limit reduction).
```
