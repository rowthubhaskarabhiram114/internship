import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, ExtraTreesClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

def train_and_evaluate_models(dataset_path="ecommerce_customer_churn.csv", output_dir="models"):
    os.makedirs(output_dir, exist_ok=True)
    
    print(f"[*] Loading dataset from {dataset_path}...")
    df = pd.read_csv(dataset_path)
    
    # Feature columns
    numerical_features = [
        'Account_Age_Months',
        'Monthly_Spend',
        'Purchase_Frequency',
        'Days_Since_Last_Purchase',
        'Customer_Support_Calls',
        'Satisfaction_Score',
        'Cart_Abandonment_Rate',
        'Discount_Usage_Ratio'
    ]
    
    categorical_features = [
        'Subscription_Tier',
        'Device_Type',
        'Payment_Method'
    ]
    
    target = 'Churn'
    
    X = df[numerical_features + categorical_features]
    y = df[target]
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    
    print(f"[+] Training set: {X_train.shape[0]} samples, Testing set: {X_test.shape[0]} samples")
    
    # Preprocessor
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)
        ]
    )
    
    # Model Suite
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Random Forest": RandomForestClassifier(n_estimators=150, max_depth=10, random_state=42),
        "Gradient Boosting": GradientBoostingClassifier(n_estimators=150, learning_rate=0.08, max_depth=5, random_state=42),
        "Extra Trees": ExtraTreesClassifier(n_estimators=150, max_depth=10, random_state=42)
    }
    
    model_results = {}
    trained_pipelines = {}
    best_f1 = -1
    best_model_name = ""
    
    for name, clf in models.items():
        print(f"[*] Training {name}...")
        pipeline = Pipeline(steps=[
            ('preprocessor', preprocessor),
            ('classifier', clf)
        ])
        
        pipeline.fit(X_train, y_train)
        y_pred = pipeline.predict(X_test)
        y_proba = pipeline.predict_proba(X_test)[:, 1] if hasattr(pipeline, "predict_proba") else None
        
        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred)
        rec = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        roc_auc = roc_auc_score(y_test, y_proba) if y_proba is not None else 0.0
        cm = confusion_matrix(y_test, y_pred).tolist()
        
        model_results[name] = {
            "accuracy": round(float(acc), 4),
            "precision": round(float(prec), 4),
            "recall": round(float(rec), 4),
            "f1_score": round(float(f1), 4),
            "roc_auc": round(float(roc_auc), 4),
            "confusion_matrix": cm,
            "test_samples": int(len(y_test))
        }
        
        trained_pipelines[name] = pipeline
        
        # Save individual model
        model_filename = f"{output_dir}/{name.lower().replace(' ', '_')}_pipeline.pkl"
        joblib.dump(pipeline, model_filename)
        
        if f1 > best_f1:
            best_f1 = f1
            best_model_name = name

    print(f"\n[BEST] Best Performing Model: {best_model_name} (F1-Score: {best_f1:.4f})")
    
    # Save the best model as main
    joblib.dump(trained_pipelines[best_model_name], f"{output_dir}/best_model.pkl")
    
    # Extract Feature Importances from Best or Tree Model
    best_pipeline = trained_pipelines[best_model_name]
    fitted_preprocessor = best_pipeline.named_steps['preprocessor']
    fitted_classifier = best_pipeline.named_steps['classifier']
    
    cat_encoder = fitted_preprocessor.named_transformers_['cat']
    encoded_cat_names = list(cat_encoder.get_feature_names_out(categorical_features))
    all_feature_names = numerical_features + encoded_cat_names
    
    feature_importances = {}
    if hasattr(fitted_classifier, "feature_importances_"):
        importances = fitted_classifier.feature_importances_
        sorted_indices = np.argsort(importances)[::-1]
        for idx in sorted_indices:
            feature_importances[all_feature_names[idx]] = round(float(importances[idx]), 4)
    elif hasattr(fitted_classifier, "coef_"):
        coefs = np.abs(fitted_classifier.coef_[0])
        sorted_indices = np.argsort(coefs)[::-1]
        for idx in sorted_indices:
            feature_importances[all_feature_names[idx]] = round(float(coefs[idx]), 4)
            
    summary_data = {
        "best_model": best_model_name,
        "models_evaluated": list(models.keys()),
        "metrics": model_results,
        "feature_importances": feature_importances,
        "numerical_features": numerical_features,
        "categorical_features": {
            "Subscription_Tier": ["Basic", "Premium", "VIP"],
            "Device_Type": ["Mobile App", "Desktop", "Tablet"],
            "Payment_Method": ["Credit Card", "UPI/Debit", "Digital Wallet", "COD"]
        }
    }
    
    with open(f"{output_dir}/model_metrics.json", "w") as f:
        json.dump(summary_data, f, indent=4)
        
    print(f"[OK] Training complete. Saved metrics and models into '{output_dir}/'.")

if __name__ == "__main__":
    train_and_evaluate_models()
