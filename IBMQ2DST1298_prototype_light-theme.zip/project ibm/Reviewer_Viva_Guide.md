# Reviewer & Viva Examination Guide

This guide gives you the exact words to say during your project evaluation, presentation, and viva voce.

---

## 🎯 Part 1: The "2-Minute Elevator Pitch" (Memorize This!)

> *"Respected Reviewers, customer acquisition is up to 7 times more expensive than customer retention. In e-commerce, customers rarely announce their departure—they silently stop purchasing.*
>
> *To solve this, we developed **ChurnGuard AI**—an E-Commerce Customer Churn Early Warning System.*
>
> *Our system ingests customer behavioural metrics like purchase recency, support tickets, cart abandonment, and monthly spending. We trained and benchmarked multiple machine learning models—including Logistic Regression, Random Forest, Gradient Boosting, and Extra Trees.*
>
> *Our best pipeline achieves an **Accuracy of 93.17%**, an **F1-Score of 91.98%**, and an **ROC-AUC of 0.9836** with high Recall to ensure at-risk customers are caught early.*
>
> *Beyond raw predictions, our prototype includes **Explainable AI** to highlight why someone is leaving, an **Automated Retention Strategy Engine** to trigger targeted discounts or VIP escalations, an **Interactive What-If Simulator**, and a **Batch CSV Scanner** that estimates annual revenue at risk.*
>
> *Let me demonstrate the live system."*

---

## 🖥️ Part 2: Step-by-Step Live Demo Walkthrough Script

### Step 1: Open the Web Application (`http://127.0.0.1:5000`)
- **Say:** *"Here is our responsive web dashboard built with Flask and modern UI aesthetics."*

### Step 2: Show the Live Predictor Tab
- **Action:** Click on the **"🚨 High Risk VIP"** preset button at the top right.
- **Say:** *"With one click, we load an at-risk profile: a user with 5 support complaints, 85 days since last purchase, and 85% cart abandonment. When I click 'Compute Early Warning Score', the system instantly calculates an 88%+ churn probability, assigns a 'Critical Risk' badge, and computes the Annual Revenue at Risk."*
- **Highlight:** *"Notice how below the gauge, the Automated Retention Engine dynamically prescribes concrete actions: 'Urgent Support Escalation within 24h' and 'Win-Back Re-engagement Campaign with 20% discount'."*

### Step 3: Show the Model Comparison Arena Tab
- **Action:** Click the **"Model Comparison"** tab.
- **Say:** *"Here we compare four algorithms side-by-side. Logistic Regression and Gradient Boosting deliver top performance. On the right, our Feature Importance chart proves that 'Days Since Last Purchase', 'Satisfaction Score', and 'Support Complaints' are the top predictors of churn."*

### Step 4: Show the What-If Simulator Tab
- **Action:** Click the **"What-If Simulator"** tab.
- **Say:** *"This is an interactive simulation for management. If customer service steps in and reduces the support calls from 5 to 0, watch how the churn risk drops in real-time from 78% down to 14%—moving the customer into the safe zone."*

### Step 5: Show the Batch CSV Scanner & ROI Calculator Tabs
- **Action:** Click the **"Batch Scanner"** and **"ROI Calculator"** tabs.
- **Say:** *"Operations teams can upload an entire database CSV to scan thousands of records in seconds. Finally, our ROI Calculator proves that preserving even 35% of at-risk users saves over $280,000 annually for a typical store."*

---

## ❓ Part 3: Top 15 Tough Viva Questions & Answers

#### Q1: Why is customer churn prediction framed as a classification problem?
**Answer:** Because the business objective is to categorize each customer into a discrete state: will they churn (`1`) or remain active (`0`) within a defined observation window, accompanied by a calibrated probability score for risk prioritization.

#### Q2: Why is Accuracy alone NOT sufficient to evaluate a churn model?
**Answer:** In real-world customer datasets, churn is often imbalanced (e.g., 10% churn, 90% retained). A naive model predicting "all retained" would have 90% accuracy but 0% utility. Therefore, we evaluate **Precision, Recall, F1-Score, and ROC-AUC**. High **Recall** is especially critical so we don't miss true churners.

#### Q3: What is the difference between Precision and Recall in this business context?
- **Precision:** Of all customers predicted to churn, how many actually churned? (High precision prevents wasting marketing budget on discounts for safe users).
- **Recall (Sensitivity):** Of all actual churners, how many did the model detect? (High recall ensures we don't lose valuable customers unnoticed).

#### Q4: How did you handle data preprocessing and categorical features?
**Answer:** We used Scikit-Learn's `ColumnTransformer` inside an integrated `Pipeline`. Numerical features were standardized using `StandardScaler` (zero mean, unit variance), and categorical features (`Subscription_Tier`, `Device_Type`, `Payment_Method`) were transformed using `OneHotEncoder(handle_unknown='ignore')`.

#### Q5: Why did you test multiple models instead of just one?
**Answer:** Different algorithms offer different trade-offs. Linear models (Logistic Regression) offer extreme speed and high interpretability. Tree ensembles (Random Forest, Gradient Boosting) capture complex non-linear feature interactions and feature importance. Benchmarking multiple models ensures empirical validation.

#### Q6: How do you prevent Data Leakage?
**Answer:** All preprocessing transformations (fitting the scaler and encoder) were fitted strictly on the **Training set** and then applied to the Test set and production inference pipeline via `Pipeline`.

#### Q7: What are the top 3 strongest predictors of customer churn in your dataset?
**Answer:** 
1. **Recency (`Days_Since_Last_Purchase`):** Inactivity is the earliest leading indicator.
2. **Customer Satisfaction Score (`Satisfaction_Score`):** Low ratings strongly trigger churn.
3. **Friction Tickets (`Customer_Support_Calls`):** Repeated support issues indicate unresolved customer frustration.

#### Q8: What is the "Revenue at Risk" metric?
**Answer:** It is calculated as $\text{Monthly Spend} \times 12 \times P(\text{Churn})$. It quantifies the expected annualized dollar loss if no retention intervention is performed.

#### Q9: What is Explainable AI (XAI) and how does your prototype use it?
**Answer:** XAI explains the reasoning behind black-box ML outputs. Our prototype extracts model weights / tree importances to show stakeholders exactly which features pushed a customer into the high-risk category.

#### Q10: How would you handle real-time streaming data in a large production system?
**Answer:** In production, we would stream events via Apache Kafka or AWS Kinesis, compute rolling aggregations (e.g. 30-day purchases, support tickets), and trigger model inference through a scalable microservice (FastAPI/Docker on Kubernetes).

#### Q11: What is the purpose of the "What-If Simulator"?
**Answer:** It serves as a prescriptive decision-support tool. It allows business managers to simulate counterfactual scenarios (e.g., "What if we resolve their support complaints?") to measure expected reduction in churn risk before committing resources.

#### Q12: How does the system handle Class Imbalance?
**Answer:** We use stratified train-test splitting to maintain class proportions, and the classification algorithms can incorporate `class_weight='balanced'` to penalize false negatives proportionally.

#### Q13: What happens if a new categorical value appears in production?
**Answer:** Our `OneHotEncoder` was initialized with `handle_unknown='ignore'`. Any unseen category is safely encoded as a zero vector without causing runtime exceptions.

#### Q14: How often should this model be retrained in production?
**Answer:** Customer behavior evolves over time (concept drift / data drift). The model should be retrained periodically (e.g., monthly) or triggered automatically when drift monitoring detects a drop in F1-Score.

#### Q15: What is the main business benefit of this project over existing solutions?
**Answer:** Traditional systems are reactive (offering discounts after the customer leaves). Our system is **proactive and prescriptive**—it identifies friction early and automatically generates targeted, cost-effective retention actions.
