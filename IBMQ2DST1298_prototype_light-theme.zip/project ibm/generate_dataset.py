import numpy as np
import pandas as pd

def generate_ecommerce_churn_dataset(n_samples=2500, random_state=42):
    """
    Generates a realistic E-Commerce Customer Churn Dataset with key business metrics:
    - CustomerID
    - Account_Age_Months (Tenure)
    - Monthly_Spend ($)
    - Purchase_Frequency (orders per month)
    - Days_Since_Last_Purchase
    - Customer_Support_Calls (number of complaints/inquiries)
    - Satisfaction_Score (1 to 5)
    - Cart_Abandonment_Rate (0.0 to 1.0)
    - Discount_Usage_Ratio (0.0 to 1.0)
    - Subscription_Tier (Basic, Premium, VIP)
    - Device_Type (Mobile App, Desktop, Tablet)
    - Payment_Method (Credit Card, UPI/Debit, Digital Wallet, Cash on Delivery)
    - Churn (0 = Retained, 1 = Churned)
    """
    np.random.seed(random_state)

    customer_ids = [f"CUST-{10000 + i}" for i in range(n_samples)]
    
    # Account Age (months): 1 to 60
    account_age = np.random.randint(1, 61, size=n_samples)
    
    # Monthly Spend ($): $15 to $450
    monthly_spend = np.round(np.random.gamma(shape=3.0, scale=35.0, size=n_samples) + 20, 2)
    monthly_spend = np.clip(monthly_spend, 15.0, 500.0)
    
    # Purchase Frequency (orders/month): 0 to 18
    purchase_frequency = np.random.poisson(lam=3.5, size=n_samples)
    purchase_frequency = np.clip(purchase_frequency, 0, 20)
    
    # Days Since Last Purchase: 1 to 120
    days_since_last_purchase = np.random.randint(1, 121, size=n_samples)
    
    # Customer Support Calls: 0 to 10
    support_calls = np.random.poisson(lam=1.8, size=n_samples)
    support_calls = np.clip(support_calls, 0, 10)
    
    # Satisfaction Score (1 to 5)
    satisfaction_score = np.random.choice([1, 2, 3, 4, 5], size=n_samples, p=[0.12, 0.18, 0.25, 0.30, 0.15])
    
    # Cart Abandonment Rate: 0.05 to 0.95
    cart_abandonment_rate = np.round(np.random.beta(a=2.5, b=2.5, size=n_samples), 2)
    
    # Discount Usage Ratio: 0.0 to 1.0
    discount_usage_ratio = np.round(np.random.beta(a=2, b=4, size=n_samples), 2)
    
    # Categorical Attributes
    subscription_tier = np.random.choice(['Basic', 'Premium', 'VIP'], size=n_samples, p=[0.55, 0.32, 0.13])
    device_type = np.random.choice(['Mobile App', 'Desktop', 'Tablet'], size=n_samples, p=[0.60, 0.30, 0.10])
    payment_method = np.random.choice(['Credit Card', 'UPI/Debit', 'Digital Wallet', 'COD'], size=n_samples, p=[0.40, 0.30, 0.20, 0.10])

    # Realistic Ground-Truth Churn Probability Formula (Log-Odds)
    log_odds = (
        - 0.04 * account_age
        - 0.003 * monthly_spend
        - 0.25 * purchase_frequency
        + 0.035 * days_since_last_purchase
        + 0.55 * support_calls
        - 0.65 * satisfaction_score
        + 1.80 * cart_abandonment_rate
        + 0.40 * discount_usage_ratio
        + np.where(subscription_tier == 'Basic', 0.4, np.where(subscription_tier == 'VIP', -0.6, 0.0))
        + np.where(payment_method == 'COD', 0.5, 0.0)
        - 0.2 # baseline intercept
    )
    
    # Add random noise
    log_odds += np.random.normal(0, 0.5, size=n_samples)
    
    # Sigmoid function for probability
    churn_prob = 1 / (1 + np.exp(-log_odds))
    churn = (churn_prob > 0.48).astype(int)

    df = pd.DataFrame({
        'CustomerID': customer_ids,
        'Account_Age_Months': account_age,
        'Monthly_Spend': monthly_spend,
        'Purchase_Frequency': purchase_frequency,
        'Days_Since_Last_Purchase': days_since_last_purchase,
        'Customer_Support_Calls': support_calls,
        'Satisfaction_Score': satisfaction_score,
        'Cart_Abandonment_Rate': cart_abandonment_rate,
        'Discount_Usage_Ratio': discount_usage_ratio,
        'Subscription_Tier': subscription_tier,
        'Device_Type': device_type,
        'Payment_Method': payment_method,
        'Churn': churn
    })

    return df

if __name__ == "__main__":
    df = generate_ecommerce_churn_dataset(n_samples=3000, random_state=42)
    output_path = "ecommerce_customer_churn.csv"
    df.to_csv(output_path, index=False)
    print(f"[OK] Generated {len(df)} samples saved to '{output_path}'.")
    print(f"Churn Distribution:\n{df['Churn'].value_counts(normalize=True).round(3) * 100}%")
