import os
import json
import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, jsonify, send_file
import io

app = Flask(__name__)

MODELS_DIR = "models"
METRICS_FILE = os.path.join(MODELS_DIR, "model_metrics.json")
BEST_MODEL_FILE = os.path.join(MODELS_DIR, "best_model.pkl")

# Load models and metadata
models_dict = {}
model_metrics = {}

def load_resources():
    global models_dict, model_metrics
    if os.path.exists(METRICS_FILE):
        with open(METRICS_FILE, "r") as f:
            model_metrics = json.load(f)
            
    # Load all available pipelines
    if os.path.exists(MODELS_DIR):
        for fname in os.listdir(MODELS_DIR):
            if fname.endswith("_pipeline.pkl"):
                model_name = fname.replace("_pipeline.pkl", "").replace("_", " ").title()
                try:
                    models_dict[model_name] = joblib.load(os.path.join(MODELS_DIR, fname))
                except Exception as e:
                    print(f"Error loading {fname}: {e}")
                    
    if os.path.exists(BEST_MODEL_FILE) and "Best" not in models_dict:
        models_dict["Best Model"] = joblib.load(BEST_MODEL_FILE)

load_resources()

def calculate_retention_recommendations(features_dict, churn_prob):
    """
    Rule-based and AI-driven Retention Strategy Engine
    Generates actionable, contextual interventions based on high-risk indicators.
    """
    recommendations = []
    
    # 1. Customer Support Complaints
    if features_dict.get('Customer_Support_Calls', 0) >= 3:
        recommendations.append({
            "type": "Urgent Support Escalation",
            "action": "Assign a dedicated Senior Account Manager to resolve ongoing unresolved tickets within 24 hours.",
            "impact": "Reduces churn probability by ~22%"
        })
        
    # 2. Inactive / Days Since Last Purchase
    if features_dict.get('Days_Since_Last_Purchase', 0) >= 45:
        recommendations.append({
            "type": "Win-Back Re-engagement Campaign",
            "action": "Send an exclusive 'We miss you' personalized email with a 20% discount coupon valid for 7 days.",
            "impact": "Increases purchase reactivation rate by ~18%"
        })
        
    # 3. High Cart Abandonment
    if features_dict.get('Cart_Abandonment_Rate', 0) >= 0.50:
        recommendations.append({
            "type": "Cart Recovery Automation",
            "action": "Trigger automated SMS/Push notification with free shipping or a 10% instant checkout incentive.",
            "impact": "Recovers ~15% abandoned carts"
        })
        
    # 4. Low Satisfaction Score
    if features_dict.get('Satisfaction_Score', 3) <= 2:
        recommendations.append({
            "type": "Customer Feedback & Apology Outreach",
            "action": "Initiate automated feedback survey with direct apology and complimentary reward points / $15 store credit.",
            "impact": "Improves customer sentiment and loyalty"
        })
        
    # 5. Low Frequency / High Monthly Spend (VIP at Risk)
    if features_dict.get('Monthly_Spend', 0) >= 150 and features_dict.get('Purchase_Frequency', 0) <= 2:
        recommendations.append({
            "type": "VIP Loyalty Upgrade",
            "action": "Offer a complimentary 3-month VIP tier upgrade with priority shipping and early access to sales.",
            "impact": "Protects high-value customer lifetime value"
        })
        
    if not recommendations:
        if churn_prob > 0.5:
            recommendations.append({
                "type": "General Retention Offer",
                "action": "Provide a loyalty bonus package and personalized product recommendations based on past browsing.",
                "impact": "Sustains active engagement"
            })
        else:
            recommendations.append({
                "type": "Loyalty Appreciation",
                "action": "Customer is healthy! Send thank-you loyalty reward points or early product access to boost NPS.",
                "impact": "Fosters long-term brand advocacy"
            })
            
    return recommendations

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/metrics", methods=["GET"])
def get_metrics():
    if not model_metrics:
        load_resources()
    return jsonify(model_metrics)

@app.route("/api/sample-customer", methods=["GET"])
def get_sample_customer():
    """Returns random sample presets (High Risk, Moderate Risk, Low Risk)."""
    samples = {
        "high_risk": {
            "Account_Age_Months": 3,
            "Monthly_Spend": 45.0,
            "Purchase_Frequency": 1,
            "Days_Since_Last_Purchase": 85,
            "Customer_Support_Calls": 5,
            "Satisfaction_Score": 1,
            "Cart_Abandonment_Rate": 0.85,
            "Discount_Usage_Ratio": 0.10,
            "Subscription_Tier": "Basic",
            "Device_Type": "Mobile App",
            "Payment_Method": "COD"
        },
        "moderate_risk": {
            "Account_Age_Months": 14,
            "Monthly_Spend": 120.0,
            "Purchase_Frequency": 3,
            "Days_Since_Last_Purchase": 40,
            "Customer_Support_Calls": 2,
            "Satisfaction_Score": 3,
            "Cart_Abandonment_Rate": 0.50,
            "Discount_Usage_Ratio": 0.30,
            "Subscription_Tier": "Premium",
            "Device_Type": "Desktop",
            "Payment_Method": "UPI/Debit"
        },
        "low_risk": {
            "Account_Age_Months": 36,
            "Monthly_Spend": 280.0,
            "Purchase_Frequency": 7,
            "Days_Since_Last_Purchase": 6,
            "Customer_Support_Calls": 0,
            "Satisfaction_Score": 5,
            "Cart_Abandonment_Rate": 0.15,
            "Discount_Usage_Ratio": 0.45,
            "Subscription_Tier": "VIP",
            "Device_Type": "Mobile App",
            "Payment_Method": "Credit Card"
        }
    }
    return jsonify(samples)

@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.json
    selected_model_name = data.get("model", "Best Model")
    
    # Select pipeline
    pipeline = models_dict.get(selected_model_name) or models_dict.get("Best Model") or list(models_dict.values())[0]
    
    input_data = {
        'Account_Age_Months': [float(data.get('Account_Age_Months', 12))],
        'Monthly_Spend': [float(data.get('Monthly_Spend', 50))],
        'Purchase_Frequency': [int(data.get('Purchase_Frequency', 3))],
        'Days_Since_Last_Purchase': [int(data.get('Days_Since_Last_Purchase', 15))],
        'Customer_Support_Calls': [int(data.get('Customer_Support_Calls', 1))],
        'Satisfaction_Score': [int(data.get('Satisfaction_Score', 4))],
        'Cart_Abandonment_Rate': [float(data.get('Cart_Abandonment_Rate', 0.25))],
        'Discount_Usage_Ratio': [float(data.get('Discount_Usage_Ratio', 0.20))],
        'Subscription_Tier': [str(data.get('Subscription_Tier', 'Basic'))],
        'Device_Type': [str(data.get('Device_Type', 'Mobile App'))],
        'Payment_Method': [str(data.get('Payment_Method', 'Credit Card'))]
    }
    
    df_input = pd.DataFrame(input_data)
    
    # Prediction & Probabilities
    churn_pred = int(pipeline.predict(df_input)[0])
    churn_proba = float(pipeline.predict_proba(df_input)[0][1]) if hasattr(pipeline, "predict_proba") else (1.0 if churn_pred == 1 else 0.0)
    
    # Risk Category
    if churn_proba < 0.30:
        risk_tier = "Low Risk (Safe)"
        risk_color = "#10b981" # Emerald Green
        risk_badge = "success"
    elif churn_proba < 0.65:
        risk_tier = "Moderate Risk (Warning)"
        risk_color = "#f59e0b" # Amber
        risk_badge = "warning"
    else:
        risk_tier = "Critical Risk (Action Required)"
        risk_color = "#ef4444" # Coral Red
        risk_badge = "danger"
        
    # Estimated Revenue at Risk (Monthly Spend * 12 months * Churn Proba)
    monthly_spend = float(data.get('Monthly_Spend', 50))
    annual_revenue_at_risk = round(monthly_spend * 12 * churn_proba, 2)
    
    # Key Drivers
    raw_dict = {k: v[0] for k, v in input_data.items()}
    recommendations = calculate_retention_recommendations(raw_dict, churn_proba)
    
    return jsonify({
        "churn_prediction": churn_pred,
        "churn_probability": round(churn_proba * 100, 2),
        "risk_tier": risk_tier,
        "risk_color": risk_color,
        "risk_badge": risk_badge,
        "annual_revenue_at_risk": annual_revenue_at_risk,
        "monthly_spend": monthly_spend,
        "recommendations": recommendations,
        "model_used": selected_model_name
    })

@app.route("/api/what-if", methods=["POST"])
def what_if_simulation():
    data = request.json
    pipeline = models_dict.get("Best Model") or list(models_dict.values())[0]
    
    # Baseline vs Modified
    baseline = data.get("baseline", {})
    modified = data.get("modified", {})
    
    def format_df(raw):
        return pd.DataFrame({
            'Account_Age_Months': [float(raw.get('Account_Age_Months', 12))],
            'Monthly_Spend': [float(raw.get('Monthly_Spend', 50))],
            'Purchase_Frequency': [int(raw.get('Purchase_Frequency', 3))],
            'Days_Since_Last_Purchase': [int(raw.get('Days_Since_Last_Purchase', 15))],
            'Customer_Support_Calls': [int(raw.get('Customer_Support_Calls', 1))],
            'Satisfaction_Score': [int(raw.get('Satisfaction_Score', 4))],
            'Cart_Abandonment_Rate': [float(raw.get('Cart_Abandonment_Rate', 0.25))],
            'Discount_Usage_Ratio': [float(raw.get('Discount_Usage_Ratio', 0.20))],
            'Subscription_Tier': [str(raw.get('Subscription_Tier', 'Basic'))],
            'Device_Type': [str(raw.get('Device_Type', 'Mobile App'))],
            'Payment_Method': [str(raw.get('Payment_Method', 'Credit Card'))]
        })
        
    df_base = format_df(baseline)
    df_mod = format_df(modified)
    
    base_proba = float(pipeline.predict_proba(df_base)[0][1])
    mod_proba = float(pipeline.predict_proba(df_mod)[0][1])
    
    prob_delta = round((mod_proba - base_proba) * 100, 2)
    
    return jsonify({
        "baseline_probability": round(base_proba * 100, 2),
        "modified_probability": round(mod_proba * 100, 2),
        "delta_percentage": prob_delta,
        "improvement": prob_delta < 0
    })

@app.route("/api/batch-predict", methods=["POST"])
def batch_predict():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
        
    file = request.files['file']
    if not file.filename.endswith('.csv'):
        return jsonify({"error": "Only CSV files are supported"}), 400
        
    df = pd.read_csv(file)
    pipeline = models_dict.get("Best Model") or list(models_dict.values())[0]
    
    required_cols = [
        'Account_Age_Months', 'Monthly_Spend', 'Purchase_Frequency',
        'Days_Since_Last_Purchase', 'Customer_Support_Calls', 'Satisfaction_Score',
        'Cart_Abandonment_Rate', 'Discount_Usage_Ratio', 'Subscription_Tier',
        'Device_Type', 'Payment_Method'
    ]
    
    missing_cols = [c for c in required_cols if c not in df.columns]
    if missing_cols:
        return jsonify({"error": f"Missing required columns: {', '.join(missing_cols)}"}), 400
        
    X = df[required_cols]
    preds = pipeline.predict(X)
    probas = pipeline.predict_proba(X)[:, 1] if hasattr(pipeline, "predict_proba") else preds
    
    df['Predicted_Churn'] = preds
    df['Churn_Risk_Percentage'] = np.round(probas * 100, 1)
    df['Risk_Level'] = np.where(probas >= 0.65, 'Critical', np.where(probas >= 0.30, 'Moderate', 'Low'))
    
    total_customers = len(df)
    churn_count = int(np.sum(preds == 1))
    churn_rate = round((churn_count / total_customers) * 100, 2)
    
    total_monthly_revenue = float(df['Monthly_Spend'].sum())
    revenue_at_risk = float((df[df['Predicted_Churn'] == 1]['Monthly_Spend'] * 12).sum())
    
    # Top 15 high risk customers
    high_risk_table = df.sort_values(by='Churn_Risk_Percentage', ascending=False).head(15)
    sample_records = high_risk_table[[
        'CustomerID' if 'CustomerID' in df.columns else 'Account_Age_Months',
        'Monthly_Spend', 'Days_Since_Last_Purchase', 'Customer_Support_Calls',
        'Satisfaction_Score', 'Churn_Risk_Percentage', 'Risk_Level'
    ]].to_dict(orient='records')
    
    return jsonify({
        "total_customers": total_customers,
        "predicted_churn_count": churn_count,
        "predicted_retained_count": total_customers - churn_count,
        "churn_rate": churn_rate,
        "total_monthly_revenue": round(total_monthly_revenue, 2),
        "annual_revenue_at_risk": round(revenue_at_risk, 2),
        "risk_breakdown": {
            "Critical": int((df['Risk_Level'] == 'Critical').sum()),
            "Moderate": int((df['Risk_Level'] == 'Moderate').sum()),
            "Low": int((df['Risk_Level'] == 'Low').sum())
        },
        "top_at_risk_customers": sample_records
    })

CUSTOMER_DIRECTORY = [
    {
        "id": "FK-88210",
        "name": "Rahul Verma",
        "email": "rahul.v@gmail.com",
        "Account_Age_Months": 24,
        "Purchase_Frequency": 12,
        "Monthly_Spend": 240.0,
        "Monthly_Spend_INR": "₹18,500",
        "Days_Since_Last_Purchase": 3,
        "recency_text": "3 days ago",
        "Customer_Support_Calls": 0,
        "Satisfaction_Score": 5,
        "Cart_Abandonment_Rate": 0.10,
        "Discount_Usage_Ratio": 0.30,
        "Subscription_Tier": "VIP",
        "Device_Type": "Mobile App",
        "Payment_Method": "Credit Card",
        "risk_category": "Low",
        "risk_prob": 6.8
    },
    {
        "id": "FK-77419",
        "name": "Priya Sharma",
        "email": "priya.s@yahoo.com",
        "Account_Age_Months": 5,
        "Purchase_Frequency": 1,
        "Monthly_Spend": 18.0,
        "Monthly_Spend_INR": "₹1,200",
        "Days_Since_Last_Purchase": 48,
        "recency_text": "48 days ago",
        "Customer_Support_Calls": 1,
        "Satisfaction_Score": 2,
        "Cart_Abandonment_Rate": 0.75,
        "Discount_Usage_Ratio": 0.10,
        "Subscription_Tier": "Basic",
        "Device_Type": "Mobile App",
        "Payment_Method": "COD",
        "risk_category": "High",
        "risk_prob": 86.4
    },
    {
        "id": "FK-63912",
        "name": "Amit Patel",
        "email": "amit.patel@outlook.com",
        "Account_Age_Months": 14,
        "Purchase_Frequency": 2,
        "Monthly_Spend": 65.0,
        "Monthly_Spend_INR": "₹4,800",
        "Days_Since_Last_Purchase": 38,
        "recency_text": "38 days ago",
        "Customer_Support_Calls": 3,
        "Satisfaction_Score": 2,
        "Cart_Abandonment_Rate": 0.60,
        "Discount_Usage_Ratio": 0.20,
        "Subscription_Tier": "Premium",
        "Device_Type": "Desktop",
        "Payment_Method": "UPI/Debit",
        "risk_category": "High",
        "risk_prob": 78.2
    },
    {
        "id": "FK-51204",
        "name": "Sneha Reddy",
        "email": "sneha.r@gmail.com",
        "Account_Age_Months": 2,
        "Purchase_Frequency": 1,
        "Monthly_Spend": 45.0,
        "Monthly_Spend_INR": "₹3,500",
        "Days_Since_Last_Purchase": 28,
        "recency_text": "28 days ago",
        "Customer_Support_Calls": 0,
        "Satisfaction_Score": 3,
        "Cart_Abandonment_Rate": 0.45,
        "Discount_Usage_Ratio": 0.15,
        "Subscription_Tier": "Basic",
        "Device_Type": "Mobile App",
        "Payment_Method": "UPI/Debit",
        "risk_category": "Medium",
        "risk_prob": 48.5
    },
    {
        "id": "FK-99301",
        "name": "Vikram Malhotra",
        "email": "vikram.m@gmail.com",
        "Account_Age_Months": 36,
        "Purchase_Frequency": 18,
        "Monthly_Spend": 420.0,
        "Monthly_Spend_INR": "₹32,000",
        "Days_Since_Last_Purchase": 2,
        "recency_text": "2 days ago",
        "Customer_Support_Calls": 0,
        "Satisfaction_Score": 5,
        "Cart_Abandonment_Rate": 0.08,
        "Discount_Usage_Ratio": 0.40,
        "Subscription_Tier": "VIP",
        "Device_Type": "Mobile App",
        "Payment_Method": "Credit Card",
        "risk_category": "Low",
        "risk_prob": 4.2
    },
    {
        "id": "FK-40291",
        "name": "Ananya Roy",
        "email": "ananya.roy@hotmail.com",
        "Account_Age_Months": 8,
        "Purchase_Frequency": 3,
        "Monthly_Spend": 38.0,
        "Monthly_Spend_INR": "₹2,800",
        "Days_Since_Last_Purchase": 24,
        "recency_text": "24 days ago",
        "Customer_Support_Calls": 1,
        "Satisfaction_Score": 3,
        "Cart_Abandonment_Rate": 0.40,
        "Discount_Usage_Ratio": 0.25,
        "Subscription_Tier": "Basic",
        "Device_Type": "Desktop",
        "Payment_Method": "Digital Wallet",
        "risk_category": "Medium",
        "risk_prob": 42.1
    },
    {
        "id": "FK-31980",
        "name": "Kavita Nair",
        "email": "kavita.n@gmail.com",
        "Account_Age_Months": 4,
        "Purchase_Frequency": 0,
        "Monthly_Spend": 15.0,
        "Monthly_Spend_INR": "₹950",
        "Days_Since_Last_Purchase": 55,
        "recency_text": "55 days ago",
        "Customer_Support_Calls": 2,
        "Satisfaction_Score": 1,
        "Cart_Abandonment_Rate": 0.85,
        "Discount_Usage_Ratio": 0.05,
        "Subscription_Tier": "Basic",
        "Device_Type": "Mobile App",
        "Payment_Method": "COD",
        "risk_category": "High",
        "risk_prob": 91.5
    },
    {
        "id": "FK-12845",
        "name": "Rohan Gupta",
        "email": "rohan.g@gmail.com",
        "Account_Age_Months": 28,
        "Purchase_Frequency": 8,
        "Monthly_Spend": 160.0,
        "Monthly_Spend_INR": "₹12,400",
        "Days_Since_Last_Purchase": 5,
        "recency_text": "5 days ago",
        "Customer_Support_Calls": 0,
        "Satisfaction_Score": 4,
        "Cart_Abandonment_Rate": 0.15,
        "Discount_Usage_Ratio": 0.35,
        "Subscription_Tier": "Premium",
        "Device_Type": "Mobile App",
        "Payment_Method": "Credit Card",
        "risk_category": "Low",
        "risk_prob": 8.1
    }
]

@app.route("/api/customers", methods=["GET"])
def get_customer_directory():
    return jsonify(CUSTOMER_DIRECTORY)

@app.route("/api/customers/download-csv", methods=["GET"])
def download_customers_csv():
    df_export = pd.DataFrame(CUSTOMER_DIRECTORY)
    csv_buffer = io.StringIO()
    df_export.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)
    return send_file(
        io.BytesIO(csv_buffer.getvalue().encode('utf-8')),
        mimetype="text/csv",
        as_attachment=True,
        download_name="monitored_customers.csv"
    )

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)

