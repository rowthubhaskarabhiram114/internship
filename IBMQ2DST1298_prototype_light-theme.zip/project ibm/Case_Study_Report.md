# Case Study & Project Technical Report

## Project Title
**E-Commerce Customer Churn Early Warning & Automated Retention System**

---

### Executive Summary / Abstract
Customer acquisition in the e-commerce industry costs **5 to 7 times more** than retaining existing customers. Losing customers ("churn") significantly hampers long-term profitability and customer lifetime value (LTV). This project presents an end-to-end Machine Learning Early Warning System designed to identify at-risk customers *before* they leave, explain the underlying drivers of churn, and trigger automated, personalized retention interventions. Using a multi-model comparative architecture (Logistic Regression, Random Forest, Gradient Boosting, and Extra Trees), the system achieves an **F1-Score of 91.98%** and an **ROC-AUC of 0.9836**, while offering interactive what-if simulations, batch database scanning, and revenue-at-risk calculations.

---

### 1. Business Problem & Motivation
- **The Challenge:** E-commerce stores experience silent customer attrition. Users do not formally cancel; they simply stop browsing, abandon carts, or decrease ordering frequency.
- **The Financial Impact:** A 5% increase in customer retention can increase company profits by **25% to 95%** (Bain & Company).
- **The Objective:**
  1. Build a high-precision binary classification model to predict whether a customer will churn (`Churn = 1`) or remain active (`Churn = 0`).
  2. Explain *why* a customer is churning (Explainable AI / Feature Impact).
  3. Prescribe automated marketing & support interventions to recover the customer.

---

### 2. Dataset Architecture & Feature Engineering

The system evaluates both behavioral and demographic customer features:

| Feature Name | Type | Description | Business Significance |
| :--- | :--- | :--- | :--- |
| `Account_Age_Months` | Numerical | Total months customer has been registered | Measures customer loyalty and lifecycle stage |
| `Monthly_Spend` | Numerical | Average monthly spending in USD ($) | Quantifies customer value and financial risk |
| `Purchase_Frequency` | Numerical | Average order count per month | Direct indicator of platform engagement |
| `Days_Since_Last_Purchase` | Numerical | Recency of last order | Strongest early indicator of disengagement |
| `Customer_Support_Calls` | Numerical | Number of complaint/help tickets logged | Measures friction or unresolved dissatisfaction |
| `Satisfaction_Score` | Numerical | Rating from 1 (Very Dissatisfied) to 5 (Delighted) | Explicit customer sentiment signal |
| `Cart_Abandonment_Rate` | Numerical | Ratio of abandoned carts (0.0 to 1.0) | Highlights pricing friction or UI drop-off |
| `Discount_Usage_Ratio` | Numerical | Fraction of purchases with discount codes | Identifies price-sensitive deal hunters |
| `Subscription_Tier` | Categorical | `Basic`, `Premium`, `VIP` | Customer tier & commitment level |
| `Device_Type` | Categorical | `Mobile App`, `Desktop`, `Tablet` | User channel preference |
| `Payment_Method` | Categorical | `Credit Card`, `UPI/Debit`, `Digital Wallet`, `COD` | Payment friction indicator (COD has higher churn) |
| **`Churn` (Target)** | Binary | `0` = Active / Retained, `1` = Churned | Ground truth target variable |

---

### 3. Machine Learning Methodology & Pipeline

```mermaid
graph TD
    A[Raw E-Commerce Customer Data] --> B[Data Preprocessing & Validation]
    B --> C1[StandardScaler: Numerical Features]
    B --> C2[OneHotEncoder: Categorical Features]
    C1 --> D[ColumnTransformer Pipeline]
    C2 --> D
    D --> E[Multi-Model Training Suite]
    E --> F1[Logistic Regression]
    E --> F2[Random Forest]
    E --> F3[Gradient Boosting]
    E --> F4[Extra Trees]
    F1 & F2 & F3 & F4 --> G[Evaluation: Accuracy, Precision, Recall, F1, ROC-AUC]
    G --> H[Production Serialized Model: best_model.pkl]
    H --> I[Flask REST API & Interactive UI]
```

#### Preprocessing Strategy:
- **Numerical Scaling:** Zero-mean, unit-variance standardization using `StandardScaler` to prevent high-magnitude features (e.g. Monthly Spend) from dominating distance/gradient calculations.
- **Categorical Encoding:** `OneHotEncoder(handle_unknown='ignore')` to handle multi-class nominal variables without introducing ordinal bias.
- **Data Splitting:** 80% Training (2,400 samples) and 20% Testing (600 samples) with stratified sampling to preserve class ratios.

---

### 4. Model Evaluation & Benchmark Results

The multi-model benchmark on the unseen test dataset (600 samples) yielded the following results:

| Model Architecture | Accuracy | Precision | Recall (Sensitivity) | F1-Score | ROC-AUC |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Logistic Regression (Best)** | **93.17%** | **91.80%** | **92.16%** | **91.98%** | **0.9836** |
| **Gradient Boosting** | 90.50% | 90.91% | 86.27% | 88.53% | 0.9702 |
| **Random Forest** | 88.67% | 91.19% | 81.18% | 0.8589 | 0.9666 |
| **Extra Trees** | 87.67% | 90.22% | 79.61% | 0.8458 | 0.9604 |

#### Confusion Matrix for Best Model (Logistic Regression):
- **True Negatives (Correctly identified active users):** 324
- **False Positives (Active users predicted as churn):** 21
- **False Negatives (Churned users missed):** 20
- **True Positives (Correctly identified at-risk users):** 235

> **Key Takeaway:** High **Recall (92.16%)** ensures that over 92% of actual churners are successfully caught by the early warning system before they defect.

---

### 5. Key Drivers of Churn (Explainable AI)

Global feature importance rankings reveal the top factors causing customers to leave:
1. **Days Since Last Purchase:** Recency is the strongest warning flag. Customers inactive for >45 days have an 80%+ probability of churn.
2. **Satisfaction Score:** Scores of 1 or 2 stars drastically escalate churn risk.
3. **Customer Support Complaints:** $\ge 3$ unresolved complaint tickets correlates strongly with defection.
4. **Account Age (Tenure):** Newer accounts (<6 months) are significantly more volatile than established multi-year customers.
5. **Subscription Tier:** Basic accounts churn at 3x the rate of VIP Gold members.

---

### 6. Automated Retention Strategy Engine (Prescriptive Analytics)

Rather than just displaying a risk score, the system automatically generates contextual business actions:

| Trigger Condition | Recommended Retention Intervention | Expected Business Impact |
| :--- | :--- | :--- |
| $\ge 3$ Support Calls | Assign dedicated Senior Manager for 24-hr resolution | Reduces churn risk by ~22% |
| $>45$ Days Inactive | Send personalized "We Miss You" 20% discount coupon | Boosts reactivation rate by ~18% |
| $\ge 50\%$ Cart Abandonment | Instant push notification with free shipping or 10% coupon | Recovers ~15% abandoned carts |
| Satisfaction Score $\le 2$ | Apology survey + $15 store credit bonus | Improves customer sentiment & NPS |
| Monthly Spend $\ge \$150$ & At-Risk | Complimentary 3-month VIP tier upgrade | Protects high-value customer LTV |

---

### 7. Financial Return on Investment (ROI)

For an e-commerce platform with **5,000 active customers** and an annual customer value of **$650**:
- **Expected Baseline Annual Churners (25%):** 1,250 customers
- **Revenue at Risk:** $\$812,500$
- **Retained via Early Warnings (35% campaign win rate):** 438 customers
- **Annual Revenue Saved:** **$284,700**

---

### 8. System Implementation & Deployment
- **Backend:** Python, Flask REST API, Scikit-Learn, Joblib, Pandas, NumPy
- **Frontend Dashboard:** Modern Responsive Glassmorphism UI, Chart.js, SVG circular gauges
- **Features Included:** Single Customer Live Scoring, What-If Simulator, Batch CSV Risk Scanner, Multi-Model Arena, ROI Calculator

---

### 9. Conclusion & Future Enhancements
The E-Commerce Customer Churn Early Warning System transitions churn management from a reactive post-mortem into a proactive, revenue-saving automated workflow. 

**Future Scope:**
1. Integration with CRM & Email tools (Klaviyo, HubSpot, Twilio SMS).
2. Deep Learning sequential modeling (LSTM / Transformer on clickstream session data).
3. Real-time webhooks on payment failure events.
